﻿using System;
using System.Collections.Generic;
using System.Text;
using Sandbox.Game.Entities;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Interfaces.Terminal;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.Entity;
using VRage.Game.ModAPI;
using VRage.ModAPI;
using VRage.ObjectBuilders;
using VRage.Utils;
using VRageMath;
using BlendTypeEnum = VRageRender.MyBillboard.BlendTypeEnum;
using ProtoBuf;
using Sandbox.Game;
using Sandbox.Game.EntityComponents;
using VRage;
using VRage.Game.ObjectBuilders.ComponentSystem;
using Sandbox.Game.Entities.Blocks;
using VRageRender.Messages;
using System.Diagnostics;
using System.Drawing;

namespace AngryCeltic.SolarSailMod
{
    [MyEntityComponentDescriptor(typeof(MyObjectBuilder_TerminalBlock), false, "LaserCaster")]
    public class AblativeSailLaserBlock : MyGameLogicComponent
    {
        IMyCubeBlock laser;
        MyStringId laserMat;
        Vector4 col_main = Color.Azure;
        Vector3 blockPos;
        Vector3 facingDir;
        bool beamActive = true;
        bool init_terminal_controls = false;
        MyParticleEffect particle;
        string particleEffectName = "AgressiveAblator";
        string validSailsubtype = "AblatorPanelMK0";
        long laserId;
        public override void Init(MyObjectBuilder_EntityBase objectBuilder)
        {
            laser = Entity as IMyCubeBlock;
            NeedsUpdate = MyEntityUpdateEnum.BEFORE_NEXT_FRAME;
            blockPos = laser.WorldMatrix.Translation;
            facingDir = laser.WorldMatrix.Rotation.Forward;
            laserId = laser.EntityId;
        }
        
        public override void UpdateOnceBeforeFrame()
        {
            //Damage_Electrical_Damaged
            MyParticlesManager.TryCreateParticleEffect(particleEffectName, out particle);
            particle.StopEmitting(0);
            particle.SetTranslation(blockPos);
            if (laser.CubeGrid.Physics != null)
            {
                //init before game start
                NeedsUpdate = MyEntityUpdateEnum.EACH_FRAME;
                MyAPIGateway.Utilities.MessageEntered += Utilities_MessageEntered;
                
            }
            laserMat = MyStringId.GetOrCompute("laserMat");
            if (!init_terminal_controls)
            {
                init_terminal_controls = true;
                IMyTerminalAction EngageDisengage = MyAPIGateway.TerminalControls.CreateAction<IMyTerminalBlock>("Engage/Disengage Beam");
                EngageDisengage.Name = new StringBuilder("Engage/Disengage Beam");
                EngageDisengage.ValidForGroups = true;
                EngageDisengage.Enabled = (b) => b.BlockDefinition.SubtypeId.ToLower().Contains("LaserCaster");
            }
        }
        
        private void Utilities_MessageEntered(string messageText, ref bool sendToOthers)
        {
            
            if(messageText.Contains("AC:"))
            {
                //Vector3 blockPos = laser.CubeGrid.PositionComp.GetPosition();
                
                //MatrixD blockDir = laser.CubeGrid.PositionComp.GetOrientation();
                //Vector3 facingDir = blockDir.Up;
                //MyAPIGateway.Utilities.ShowMessage("AC", "Position is " + facingDir.ToString());
            }
             
            
        }
        
        public override void UpdateAfterSimulation()
        {
            //blockPos = laser.CubeGrid.PositionComp.GetPosition();
            //MatrixD blockDir = laser.CubeGrid.PositionComp.GetOrientation(); // basically like a quaternion in Unity
            facingDir = laser.WorldMatrix.Forward; //Actual block direction according to block
            IHitInfo Hit; //exact same as casting a ray in unity, thank fuck
            blockPos = laser.WorldMatrix.Translation;



            var color = Color.Red.ToVector4();
            var color2 = Color.Blue.ToVector4();
            var color3 = Color.Green.ToVector4(); //ignore the errors they are just confused, SE gets it right
            
            //this draws a debug line except its not a debug and will show up
            MySimpleObjectDraw.DrawLine(blockPos, blockPos + facingDir * 150, MyStringId.GetOrCompute("Square"), ref color, 0.01f); //Draw the beam
            
            float hitDistance = 0;
            
            
            
            if (MyAPIGateway.Physics.CastRay(blockPos, blockPos + facingDir * 150, out Hit) && beamActive)
            {
                if (RayCastHitValid(Hit))
                {
                    hitDistance = Vector3.Distance(Hit.Position, blockPos);

                    //MyAPIGateway.Utilities.ShowMessage("AC", "I hit a grid " + hitblock.BlockDefinition.Id.SubtypeName.ToString());
                    Vector3D wsHitnormal = (Hit.Normal * 10) + Hit.Position;
                    Vector3D wsReflection = (10 * Vector3.Reflect(facingDir, Hit.Normal)) + Hit.Position;
                    Vector3D dirReflection = Vector3D.Reflect(facingDir, Hit.Normal);
                    //more debugging draw lines
                    MySimpleObjectDraw.DrawLine(Hit.Position, wsHitnormal, MyStringId.GetOrCompute("Square"), ref color2, 0.01f);
                    MySimpleObjectDraw.DrawLine(Hit.Position, wsReflection, MyStringId.GetOrCompute("Square"), ref color3, 0.01f);

                    //actual particle effect for hit

                    Matrix toParticleMatrix = Matrix.CreateFromDir(dirReflection);
                    particle.WorldMatrix = toParticleMatrix * Matrix.CreateTranslation(Hit.Position);

                    particle.Play();
                }
                else
                {
                    particle.StopEmitting(0f);
                }
            }
            
        }
        
        public bool RayCastHitValid(IHitInfo _Hit)
        {
            //MyAPIGateway.Utilities.ShowMessage("AC", "I hit: " + Hit.HitEntity.GetType().ToString());
            if (_Hit.HitEntity is IMyCubeGrid)
            {
                //MyAPIGateway.Utilities.ShowMessage("AC", "I hit a grid ");


                var grid = _Hit.HitEntity as IMyCubeGrid;
                if (grid.Physics != null)
                {
                    Vector3I grid_int = grid.WorldToGridInteger(_Hit.Position);
                    if (grid_int != null)
                    {

                        Vector3D cube_local = Vector3D.Transform(_Hit.Position, grid.WorldMatrixNormalizedInv);
                        grid.FixTargetCube(out grid_int, cube_local / grid.GridSize);
                        var hitblock = grid.GetCubeBlock(grid_int);

                        if (hitblock.BlockDefinition.Id.SubtypeName.ToString() == validSailsubtype)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                            
                    }
                        
                }
                    
            }
            return false;
        }
        
        public void DrawBeam(Vector3 endpos)
        {
            if (MyAPIGateway.Utilities.IsDedicated)
            {
                return;
            }
            //This line currently draws a pink square line
            MySimpleObjectDraw.DrawLine(blockPos, endpos, laserMat, ref col_main, 1f, BlendTypeEnum.Standard);
            
        }


        public override void Close()
        {
            MyAPIGateway.Utilities.MessageEntered -= Utilities_MessageEntered;
            particle.Stop();
        }

        private void ObsoleteRaycstMethod()
        {
            //this line is already declared its just here to get VS to shut up
            IHitInfo Hit; //exact same as casting a ray in unity, thank fuck
            if (MyAPIGateway.Physics.CastRay(blockPos, blockPos + facingDir * 150, out Hit) && beamActive)
            {
                DrawBeam(Hit.Position);

                //MyAPIGateway.Utilities.ShowMessage("AC", "I hit: " + Hit.HitEntity.GetType().ToString());
                if (Hit.HitEntity is IMyCubeGrid)
                {
                    //MyAPIGateway.Utilities.ShowMessage("AC", "I hit a grid ");


                    var grid = Hit.HitEntity as IMyCubeGrid;
                    if (grid.Physics != null)
                    {
                        Vector3I grid_int = grid.WorldToGridInteger(Hit.Position);
                        if (grid_int != null)
                        {

                            Vector3D cube_local = Vector3D.Transform(Hit.Position, grid.WorldMatrixNormalizedInv);
                            grid.FixTargetCube(out grid_int, cube_local / grid.GridSize);
                            var hitblock = grid.GetCubeBlock(grid_int);

                            if (hitblock.BlockDefinition.Id.SubtypeName.ToString() == validSailsubtype)
                            {
                                

                                //MyAPIGateway.Utilities.ShowMessage("AC", "I hit a grid " + hitblock.BlockDefinition.Id.SubtypeName.ToString());
                                Vector3D wsHitnormal = (Hit.Normal * 10) + Hit.Position;
                                Vector3D wsReflection = (10 * Vector3.Reflect(facingDir, Hit.Normal)) + Hit.Position;
                                Vector3D dirReflection = Vector3D.Reflect(facingDir, Hit.Normal);
                                //more debugging draw lines
                               // MySimpleObjectDraw.DrawLine(Hit.Position, wsHitnormal, MyStringId.GetOrCompute("Square"), ref color2, 0.01f);
                               // MySimpleObjectDraw.DrawLine(Hit.Position, wsReflection, MyStringId.GetOrCompute("Square"), ref color3, 0.01f);

                                //actual particle effect for hit

                                Matrix toParticleMatrix = Matrix.CreateFromDir(dirReflection);
                                particle.WorldMatrix = toParticleMatrix * Matrix.CreateTranslation(Hit.Position);

                                particle.Play();



                            }

                        }
                    }
                }

            }
            else
            {

                particle.StopEmitting(0f);

            }
        }
    }
}
